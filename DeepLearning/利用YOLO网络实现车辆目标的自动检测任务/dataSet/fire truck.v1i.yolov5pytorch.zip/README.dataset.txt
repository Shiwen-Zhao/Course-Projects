# fire truck > 2023-12-15 11:57pm
https://universe.roboflow.com/solmaz/fire-truck

Provided by a Roboflow user
License: CC BY 4.0

